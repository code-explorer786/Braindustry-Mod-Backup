package mindustry.entities.comp;

import mindustry.annotations.Annotations.*;
import mindustry.gen.*;

//dummy target definition
@EntityDef(value = Teamc.class, genio = false, isFinal = false)
public class PosTeamDef{
}

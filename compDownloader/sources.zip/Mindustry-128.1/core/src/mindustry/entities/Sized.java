package mindustry.entities;

import arc.math.geom.*;

public interface Sized extends Position{
    float hitSize();
}

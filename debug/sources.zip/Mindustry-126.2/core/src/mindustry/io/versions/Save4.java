package mindustry.io.versions;

import mindustry.io.*;

public class Save4 extends SaveVersion{

    public Save4(){
        super(4);
    }
}

package mindustry.entities.comp;

public interface Sized{
    float hitSize();
}
